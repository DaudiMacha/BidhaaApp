from django.apps import AppConfig


class BidhaaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'BidhaaApp'
